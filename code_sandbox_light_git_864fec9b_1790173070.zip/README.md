# Kaan-Developer — GitHub Profile Rebuild

Workspace for rebuilding the `Kaan-Developer/Kaan-Developer` GitHub profile README from the audited version.

## Contents

| Path | Purpose |
| --- | --- |
| `profile/README.md` | Final profile README — copy to the root of the `Kaan-Developer/Kaan-Developer` repo |
| `profile/assets/divider.svg` | Single palette-matched divider (used twice) |
| `profile/scripts/generate-snake.mjs` | Zero-dependency Node 18+ script that builds the custom "avoid-green" snake SVGs (dark + light) |
| `profile/.github/workflows/snake.yml` | Daily cron + manual trigger workflow that publishes the SVGs to the `output` branch |
| `profile/scripts/snake-core.mjs` | Pure rule-set + SVG renderer shared by the CLI and the browser test |
| `snake-test.html` | Browser test page: runs the simulation on 6 grids (0 %–100 % green) and asserts zero rule violations, then renders both themes |
| `source/README_original.md` | The audited (old) README, kept for reference only |

## Publishing steps

1. Copy everything inside `profile/` to the root of the `Kaan-Developer/Kaan-Developer` repository (keep the folder layout).
2. In `README.md`, search for `REPLACE` and fill every ALL-CAPS placeholder (email, LinkedIn slug, admin-panel repo name) or delete that line.
3. Push, then go to **Actions → Contribution snake → Run workflow** once so the `output` branch exists.
4. Verify both `snake-dark.svg` and `snake-light.svg` load from `raw.githubusercontent.com/Kaan-Developer/Kaan-Developer/output/`.

## Local test of the snake generator

```bash
SNAKE_MOCK=1 node profile/scripts/generate-snake.mjs   # random grid, no network
GITHUB_USER=Kaan-Developer GITHUB_TOKEN=ghp_xxx node profile/scripts/generate-snake.mjs
```

Outputs land in `dist/`.

## Not included (by design)

Stats/streak/trophy widgets, view counters, WhatsApp/Telegram links, placeholder projects, AI-tools section — all removed per the audit requirements.

/**
 * README.studio — loads README-profile.md, renders it GitHub-style,
 * and provides raw view / copy / download helpers.
 */
(function () {
  'use strict';

  const README_PATH = 'README-profile.md';

  const previewEl = document.getElementById('readme-preview');
  const rawEl = document.getElementById('readme-raw');
  const rawCodeEl = document.getElementById('readme-raw-code');
  const metaEl = document.getElementById('frame-meta');
  const copyBtn = document.getElementById('copy-btn');
  const toastEl = document.getElementById('toast');
  const tabButtons = Array.from(document.querySelectorAll('.tab-btn'));

  let markdownSource = '';

  /* ---------- Toast ---------- */
  let toastTimer = null;
  function showToast(message) {
    toastEl.textContent = message;
    toastEl.classList.add('is-visible');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove('is-visible'), 2200);
  }

  /* ---------- View switching ---------- */
  function setView(view) {
    const showRaw = view === 'raw';
    rawEl.classList.toggle('is-hidden', !showRaw);
    previewEl.classList.toggle('is-hidden', showRaw);
    tabButtons.forEach((btn) => {
      const active = btn.dataset.view === view;
      btn.classList.toggle('is-active', active);
      btn.setAttribute('aria-pressed', String(active));
    });
  }
  tabButtons.forEach((btn) => btn.addEventListener('click', () => setView(btn.dataset.view)));

  /* ---------- Copy ---------- */
  copyBtn.addEventListener('click', async () => {
    if (!markdownSource) return showToast('README not loaded yet');
    try {
      await navigator.clipboard.writeText(markdownSource);
      showToast('README markdown copied to clipboard');
    } catch (err) {
      // Fallback for browsers without async clipboard permission
      const ta = document.createElement('textarea');
      ta.value = markdownSource;
      ta.setAttribute('readonly', '');
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand('copy');
      document.body.removeChild(ta);
      showToast(ok ? 'README markdown copied to clipboard' : 'Copy failed — use the Markdown tab');
    }
  });

  /* ---------- Render ---------- */
  function renderMarkdown(src) {
    if (typeof marked === 'undefined') {
      throw new Error('marked library failed to load');
    }
    marked.setOptions({ gfm: true, breaks: false, headerIds: false, mangle: false });
    return marked.parse(src);
  }

  function updateMeta(src) {
    const lines = src.split('\n').length;
    const bytes = new Blob([src]).size;
    const kb = (bytes / 1024).toFixed(1);
    metaEl.textContent = lines + ' lines · ' + kb + ' KB';
  }

  async function init() {
    try {
      const res = await fetch(README_PATH, { cache: 'no-store' });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      markdownSource = await res.text();

      previewEl.innerHTML = renderMarkdown(markdownSource);
      rawCodeEl.textContent = markdownSource;
      updateMeta(markdownSource);
    } catch (err) {
      console.error('Failed to load README:', err);
      previewEl.innerHTML =
        '<p class="error-state">Could not load ' + README_PATH + ' (' + err.message + ').</p>';
      metaEl.textContent = 'error';
    }
  }

  init();
})();

# README.studio — GitHub Profile README Generator (Purple Edition)

A static site that hosts, previews, and exports a **GitHub Profile README** generated from the uploaded master prompt (`docs/master-prompt.pdf`). The README replicates the reference profile's structure, spacing, badge usage, dividers, collapsible project sections and GitHub analytics blocks **exactly**, re-themed from orange to a dark-luxury **Purple / Indigo / Violet** palette.

## Deliverables

| File | Purpose |
| :--- | :--- |
| `README-profile.md` | **The generated GitHub profile README** — paste into `Kaan-Developer/Kaan-Developer/README.md` |
| `assets/divider-thick.svg` | Purple gradient thick divider (6px) referenced by the README |
| `assets/divider-thin.svg` | Purple gradient thin divider (2px) referenced by the README |
| `index.html` | Preview page (GitHub-dark rendering, raw markdown tab, copy & download) |
| `css/style.css` | Site styles + GitHub-like `.markdown-body` dark theme |
| `js/main.js` | Fetches and renders the README with `marked`, copy/download logic |
| `docs/master-prompt.pdf` | Original master prompt provided by the user |

## Completed features

- Profile README with identical section order to the reference: Hero → About Me → Frontend Stack → **Featured Projects** (table + `<details>` collapsibles) → **GitHub Analytics** → AI-Assisted Workflow → Portfolio → Connect → footer sub-line → publishing checklist comment.
- Palette: `#0D1117` base · `#21262D` badge base · `#4C1D95` deep violet · `#6366F1` indigo · `#8B5CF6` violet · `#A78BFA` lavender.
- No photos / screenshots / placeholders — only SVG dividers, shields.io badges, skillicons, capsule-render banner and GitHub stat widgets (stats, top-langs, streak, activity graph, trophies).
- Preview page: sticky header, Preview / Markdown tab switch, **Copy README** (clipboard with fallback), **Download** (`README.md`), line/size meta, mobile-responsive layout.

## Entry points

- `index.html` — preview & export UI (no parameters)
- `README-profile.md` — raw markdown file (direct download)
- `assets/divider-thick.svg`, `assets/divider-thin.svg` — divider assets

## Before publishing to GitHub

1. Replace `https://YOUR-PORTFOLIO-URL.com` with the real portfolio URL.
2. Replace `YOUR-LINKEDIN` with the LinkedIn slug (or remove that badge).
3. Replace `90XXXXXXXXXX` with the WhatsApp number in international format.
4. Swap the four Featured Projects for real repositories.
5. Commit the `assets/` folder next to `README.md` in the profile repo.
6. Analytics widgets read the public user `Kaan-Developer`; change if needed. (Third-party stat services can rate-limit — they render normally on GitHub.)

## Not yet implemented / next steps

- In-browser editor for name, username, links and project rows with live re-rendering.
- Alternate palette presets (emerald, cyan, rose) using the same structure.
- Automatic username substitution across all widget URLs.

## Data & storage

No tables or backend are used — the site is fully static; the README is fetched as a plain text file at runtime.
